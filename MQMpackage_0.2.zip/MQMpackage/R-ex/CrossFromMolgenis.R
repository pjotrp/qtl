### Name: CrossFromMolgenis
### Title: CrossFromMolgenis - Helperfunction to create a cross-object from
###   a molgenis database
### Aliases: CrossFromMolgenis
### Keywords: QTL Mapping Selection

### ** Examples

cMol <- CrossFromMolgenis()                     #Make a crossobject from the database
result <- scanMQMall(cMol)                      #Basic execution of scanMQMall
ResultsToMolgenis(result,"QTL-mqm")     #Store the result from MQM into molgenis database



