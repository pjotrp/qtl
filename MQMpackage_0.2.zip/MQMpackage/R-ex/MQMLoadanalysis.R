### Name: MQMLoadanalysis
### Title: MQMLoadanalysis : Enables loading of previous MQM analysis from
###   file
### Aliases: MQMLoadanalysis
### Keywords: QTL Mapping Selection

### ** Examples

library(MQMpackage)
qtl <- c(3,15,3,7)                                      # QTL at chromosome 3
data(map10)                                             # Mouse genome
cross <- sim.cross(map10,qtl,n=100)                     # Simulate a Cross
result <- scanMQM(cross,file="aaa.txt")                 # Do a MQM scan of the genome and save it to aaa.txt
res_reloaded <- MQMLoadanalysis("aaa.txt")              #Reads in and plots the file aaa.txt



