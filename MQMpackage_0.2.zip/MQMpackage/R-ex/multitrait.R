### Name: multitrait
### Title: Example Cross object from R/QTL with multiple traits.
### Aliases: multitrait ArabidopsisLERCVI
### Keywords: datasets

### ** Examples

        library(MQMpackage)                                     #Load the package
        data(multitrait)                                                #Load dataset
        result <- scanMQMall(multitrait,doLOG=1)        #Analyse all 24 traits



