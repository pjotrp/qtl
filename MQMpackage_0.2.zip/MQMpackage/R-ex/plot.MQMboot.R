### Name: plot.MQMboot
### Title: plot.MQMboot - Plotting routine to display the results from a
###   bootstrapMQM scan
### Aliases: plot.MQMboot
### Keywords: QTL Mapping Selection

### ** Examples

#Simulated F2 Population
        library(MQMpackage)
        f2qtl <- c(3,15,3,7)                                    # QTL at chromosome 3
        data(map10)                                             # Mouse genome
        f2cross <- sim.cross(map10,f2qtl,n=100,type="f2")       # Simulate a F2 Cross
        f2result <- bootstrapMQM(f2cross)                       # Bootstrap MQM to obtain confidence intervals
        plot.MQMboot(f2result)                                                                  # Use the nice bootstrap plotting methodes



