### Name: MQMaugment
### Title: MQMaugment - Missing data augmentation routine for MQM
### Aliases: MQMaugment
### Keywords: QTL Mapping Selection

### ** Examples

        library(MQMpackage)
        qtl <- c(3,15,3,7)                                                      # QTL at chromosome 3
        data(map10)                                                             # Mouse genome
        cross <- sim.cross(map10,qtl,n=100,missing.prob=0.01)                   # Simulate a Cross
        cross_good <- MQMaugment(cross)                                         # Augmentation of the data
        result <- scanMQM(cross_good)                                           # Do a MQM scan of the genome
        plot(result)                                                            # Plot the results of the genome scan



