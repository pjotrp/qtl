### Name: scanMQMall
### Title: scanMQMall - Multitrait analysis of a cross object
### Aliases: scanMQMall
### Keywords: QTL Mapping Selection

### ** Examples

        #Doing a multitrait analysis
        library(MQMpackage)
        data(multitrait)
        result <- scanMQMall(multitrait,doLOG=1)



