### Name: scanMQM
### Title: scanMQM - Multiple qtl mapping for inbred crosses
### Aliases: scanMQM
### Keywords: QTL Mapping Selection

### ** Examples

#Simulated F2 Population
library(MQMpackage)
f2qtl <- c(3,15,3,7)                                    # QTL at chromosome 3
data(map10)                                             # Mouse genome
f2cross <- sim.cross(map10,f2qtl,n=100,type="f2")       # Simulate a F2 Cross
f2result <- scanMQM(f2cross)                            # Do a MQM scan of the genome

#Simulated BC Population
library(MQMpackage)
bcqtl <- c(3,15,2)                                      # QTL at chromosome 3
data(map10)                                             # Mouse genome
bccross <- sim.cross(map10,bcqtl,n=100,type="bc")       # Simulate a BC Cross
bcresult <- scanMQM(bccross)                            # Do a MQM scan of the genome




