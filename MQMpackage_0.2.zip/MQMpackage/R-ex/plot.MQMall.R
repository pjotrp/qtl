### Name: plot.MQMall
### Title: plot.MQMall - Plotting routine to display the results from a
###   scanMQMall / bootstrapMQM scan
### Aliases: plot.MQMall
### Keywords: QTL Mapping Selection

### ** Examples

        library(MQMpackage)
        data(multitrait)
        result <- scanMQMall(multitrait)
        plot.MQMall(result,"P")
        plot.MQMall(result,"C")



