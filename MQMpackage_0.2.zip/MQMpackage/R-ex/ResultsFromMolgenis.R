### Name: ResultsFromMolgenis
### Title: ResultsFromMolgenis - Helperfunction to retrieve results from a
###   molgenis database
### Aliases: ResultsFromMolgenis
### Keywords: QTL Mapping Selection

### ** Examples

cMol <- CrossFromMolgenis()                             #Make a crossobject from the database
result <- scanMQMall(cMol)                              #Basic execution of scanMQMall
ResultsToMolgenis(result,"QTL-mqm")                     #Store the result from MQM into molgenis database
r_res <- ResultsFromMolgenis("QTL-mqm")         #Store the result from MQM into molgenis database




