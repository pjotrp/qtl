### Name: plot.MQMone
### Title: plot.MQMone - Plotting routine to display the results from a
###   MQMscan
### Aliases: plot.MQMone
### Keywords: QTL Mapping Selection

### ** Examples

#Simulated F2 Population
        library(MQMpackage)
        f2qtl <- c(3,15,3,7)                                    # QTL at chromosome 3
        data(map10)                                             # Mouse genome
        f2cross <- sim.cross(map10,f2qtl,n=100,type="f2")       # Simulate a F2 Cross
        f2result <- scanMQM(f2cross)                               # Do a MQM scan of the genome
        plot.MQMone(f2result)                                                                   #Use our fancy plotting routine



