### Name: ResultsToMolgenis
### Title: ResultsToMolgenis - Helperfunction to store results from a
###   MQM-qtl run into a molgenis database
### Aliases: ResultsToMolgenis
### Keywords: QTL Mapping Selection

### ** Examples

cMol <- CrossFromMolgenis()                     #Make a crossobject from the database
result <- scanMQMall(cMol)                      #Basic execution of scanMQMall
ResultsToMolgenis(result,"QTL-mqm")     #Store the result from MQM into molgenis database



