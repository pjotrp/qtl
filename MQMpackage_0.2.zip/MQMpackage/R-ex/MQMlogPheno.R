### Name: MQMlogPheno
### Title: MQMlogPheno - Helper function to logtransform phenotypesin R/QTL
###   cross objects
### Aliases: MQMlogPheno
### Keywords: QTL Mapping Selection

### ** Examples

        data(multitrait)
        plot(scanMQM(MQMaugment(multitrait)))
        plot(scanMQM(MQMaugment(multitrait),doLOG=1))



