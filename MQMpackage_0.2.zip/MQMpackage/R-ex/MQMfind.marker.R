### Name: MQMfind.marker
### Title: Find the genetic markers significant after
###   bootstrapping/permutation of the data
### Aliases: MQMfind.marker
### Keywords: QTL Mapping Selection

### ** Examples

library(MQMpackage)
f2qtl <- c(3,15,3,7)                                    # QTL at chromosome 3
data(map10)                                             # Mouse genome
f2cross <- sim.cross(map10,f2qtl,n=100,type="f2")       # Simulate a F2 Cross
f2result <- bootstrapMQM(f2cross)                       # Do a MQM scan of the genome
f2perm <- MQMpermObject(f2result)                       #Create a permutation object
summary(f2perm)                                                                         #What LOD score is considered significant ?
marker <- MQMfind.marker(f2cross,f2result[[1]],f2perm)          #Find markers with a significant QTL effect (First run is original phenotype data)
marker                                                                  #print it
lodint(f2result[[1]],chr=marker[,'chr']) #extra: Confidence intervals



