### Name: MQMCofactors
### Title: MQMCofactors - Helper function to create cofactors to be used
###   with scanMQM
### Aliases: MQMCofactors
### Keywords: ~kwd1 ~kwd2

### ** Examples

library(MQMpackage)
qtl <- c(3,15,3,7)                                                                      # QTL at chromosome 3
data(map10)                                                                                     # Mouse genome
cross <- sim.cross(map10,qtl,n=100)                                     # Simulate a Cross
a <- MQMCofactors(cross,c(20,30,80,90),c(186,187))      # Set Cofactors on marker 20,30,80 & 90 and sexfactors on 186,187
result <- scanMQM(cross,a)                                                      # Do a backward model selection
plot(result)                                                                            # Plot the results of the genome scan (with the best model)



