### Name: multitrait
### Title: Crossobject from R/QTL with multiple traits
### Aliases: multitrait
### Keywords: datasets

### ** Examples

        library(MQMpackage)
        data(multitrait)
        result <- scanMQMall(multitrait,doLOG=1)



