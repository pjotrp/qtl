### Name: scanMQMall
### Title: scanMQMall - Multitrait analysis of a cross object
### Aliases: scanMQMall
### Keywords: ~kwd1 ~kwd2

### ** Examples

        #Doing a multitrait analysis
        library(MQMpackage)
        data(multitrait)
        result <- scanMQMall(multitrait,doLOG=1)



