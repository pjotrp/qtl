### Name: scanMQMall
### Title: scanMQMall - Multitrait analysis of a cross object
### Aliases: scanMQMall
### Keywords: ~kwd1 ~kwd2

### ** Examples

        library(MQMpackage)
        data(multitrait)
        result <- scanMQMall(multitrait)



