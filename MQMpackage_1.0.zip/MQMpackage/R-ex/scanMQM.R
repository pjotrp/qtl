### Name: scanMQM
### Title: scanMQM - Multiple qtl mapping
### Aliases: scanMQM
### Keywords: ~kwd1 ~kwd2

### ** Examples

        library(qtl)
        qtl <- c(3,15,+3,+7)                                                    # QTL at chromosome 3
        map10 <- data(map10)                                                    # Mouse genome
        cross <- sim.cross(map10,qtl,n=100)                             # Simulate a Cross
        result <- scanMQM(cross)



