### Name: scanMQM
### Title: scanMQM - Multiple qtl mapping for F2 crosses
### Aliases: scanMQM
### Keywords: QTL Mapping Selection

### ** Examples

        library(qtl)
        qtl <- c(3,15,3,7)                                                      # QTL at chromosome 3
        data(map10)                                                                     # Mouse genome
        cross <- sim.cross(map10,qtl,n=100)                     # Simulate a Cross
        result <- scanMQM(cross)                                        # Do a MQM scan of the genome
        plot(result)                                                            #plot the results of the genome scan



