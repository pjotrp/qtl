### Name: MQMCofactorsEach
### Title: MQMCofactorsEach - Helper function to create cofactors to be
###   used with scanMQM
### Aliases: MQMCofactorsEach
### Keywords: ~kwd1 ~kwd2

### ** Examples

library(MQMpackage)
qtl <- c(3,15,3,7)                                              # QTL at chromosome 3
data(map10)                                                     # Mouse genome
cross <- sim.cross(map10,qtl,n=100)                             # Simulate a Cross
a <- MQMCofactorsEach(cross,3)                                          # Set Cofactors each third marker
result <- scanMQM(cross,a)                                      # Do a backward model selection
plot(result)                                                    # Plot the results of the genome scan (with the best model)



