### Name: MQMlogPheno
### Title: MQMlogPheno - Helper function to logtransform phenotypesin R/QTL
###   cross objects
### Aliases: MQMlogPheno
### Keywords: ~kwd1 ~kwd2

### ** Examples

        data(multitrait)
        plot(scanMQM(MQMaugment(multitrait)))
        plot(scanMQM(MQMaugment(multitrait),doLOG=1))



