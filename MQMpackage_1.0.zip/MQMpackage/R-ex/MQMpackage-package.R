### Name: MQMpackage-package
### Title: Tool for analyzing QTL experiments
### Aliases: MQMpackage-package MQMpackage
### Keywords: package

### ** Examples

        library(MQMpackage)
        data(multitrait)
        result <- scanMQM(multitrait)
        plot(result)



