### Name: MQMpackage-package
### Title: Tool for analyzing QTL experiments
### Aliases: MQMpackage-package MQMpackage
### Keywords: package

### ** Examples

        library(MQMpackage)
        data(multitrait)
        mt_est <- MQMaugment(multitrait)
        result <- scanMQM(mt_est)
        plot(result)



