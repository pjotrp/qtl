### Name: plot.MQMall
### Title: plot.MQMall - Plotting routine to display the results from a
###   scanMQMall scan
### Aliases: plot.MQMall
### Keywords: ~kwd1 ~kwd2

### ** Examples

        library(MQMpackage)
        data(multitrait)
        result <- scanMQMall(multitrait)
        plot.MQMall(cross,result,"P")
        plot.MQMall(cross,result,"C")



